// main.cpp
#include <iostream>
#include <chrono>
#include "procesamiento.h"
#include "ventas.h"

using namespace std;
using namespace std::chrono;

int if_count = 0;
vector<Venta> ventas;

int main()
{
    auto inicio = high_resolution_clock::now(); // Tiempo inicial

    cargarCSV("ventas_sudamerica.csv");
    procesarDatos();

    int opcion_principal;
    do
    {
        cout << "\n=== Sistema de Analisis de Ventas ===\n";
        cout << "1. Modificar datos\n";
        cout << "2. Procesamientos\n";
        cout << "3. Consultas dinamicas\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion_principal;

        auto t_inicio = high_resolution_clock::now(); // Tiempo inicio de operacion

        switch (opcion_principal)
        {
        case 1:
        {
            int op;
            do
            {
                cout << "\n--- Modificar datos ---\n";
                cout << "1. Agregar nueva venta\n";
                cout << "2. Eliminar venta\n";
                cout << "3. Modificar venta\n";
                cout << "4. Volver al menu principal\n";
                cout << "Seleccione una opcion: ";
                cin >> op;

                auto t_mod = high_resolution_clock::now();

                switch (op)
                {
                case 1:
                    agregarVenta();
                    break;
                case 2:
                    eliminarVenta();
                    break;
                case 3:
                    modificarVenta();
                    break;
                case 4:
                    break;
                default:
                    cout << "Opcion invalida.\n";
                }

                auto t_mod_fin = high_resolution_clock::now();
                auto duracion_mod = duration_cast<milliseconds>(t_mod_fin - t_mod).count();
                cout << "Tiempo de ejecucion: " << duracion_mod << " ms\n";
                cout << "Condicionales (if) ejecutados: " << if_count << "\n";
                if_count = 0;

            } while (op != 4);
            break;
        }

        case 2:
        {
            int op;
            do
            {
                cout << "\n--- Procesamientos ---\n";
                cout << "1. Top 5 ciudades con mayor monto por pais\n";
                cout << "2. Monto total vendido por producto\n";
                cout << "3. Promedio de ventas por categoria\n";
                cout << "4. Medio de envio mas utilizado por pais\n";
                cout << "5. Medio de envio mas utilizado por categoria\n";
                cout << "6. Dia con mayor monto total de ventas\n";
                cout << "7. Estado de envio mas frecuente por pais\n";
                cout << "8. Producto mas vendido (por cantidad)\n";
                cout << "9. Producto menos vendido (por cantidad)\n";
                cout << "10. Volver al menu principal\n";
                cout << "Seleccione una opcion: ";
                cin >> op;

                auto t_proc = high_resolution_clock::now();

                if (op == 1)
                    top5CiudadesPorPais();
                else if (op >= 2 && op <= 9)
                    mostrarEstadisticas();
                else if (op != 10)
                    cout << "Opcion invalida.\n";

                auto t_proc_fin = high_resolution_clock::now();
                auto duracion_proc = duration_cast<milliseconds>(t_proc_fin - t_proc).count();
                cout << "Tiempo de ejecucion: " << duracion_proc << " ms\n";
                cout << "Condicionales (if) ejecutados: " << if_count << "\n";
                if_count = 0;

            } while (op != 10);
            break;
        }

        case 3:
        {
            int op;
            do
            {
                cout << "\n--- Consultas dinamicas ---\n";
                cout << "1. Listado de ventas por ciudad\n";
                cout << "2. Ventas por rango de fechas y pais\n";
                cout << "3. Comparar dos paises\n";
                cout << "4. Comparar dos productos por pais\n";
                cout << "5. Productos por debajo de umbral promedio\n";
                cout << "6. Productos por encima de umbral promedio\n";
                cout << "7. Volver al menu principal\n";
                cout << "Seleccione una opcion: ";
                cin >> op;

                auto t_con = high_resolution_clock::now();

                switch (op)
                {
                case 1:
                    consultarVentasPorCiudad();
                    break;
                case 2:
                    consultarVentasPorRangoFechaYPais();
                    break;
                case 3:
                    compararDosPaises();
                    break;
                case 4:
                    compararDosProductosPorPais();
                    break;
                case 5:
                    buscarProductosPorDebajoDelUmbral();
                    break;
                case 6:
                    buscarProductosPorEncimaDelUmbral();
                    break;
                case 7:
                    break;
                default:
                    cout << "Opcion invalida.\n";
                }

                auto t_con_fin = high_resolution_clock::now();
                auto duracion_con = duration_cast<milliseconds>(t_con_fin - t_con).count();
                cout << "Tiempo de ejecucion: " << duracion_con << " ms\n";
                cout << "Condicionales (if) ejecutados: " << if_count << "\n";
                if_count = 0;

            } while (op != 7);
            break;
        }

        case 4:
            cout << "\nSaliendo del sistema...\n";
            break;

        default:
            cout << "Opcion invalida.\n";
        }

        auto t_fin = high_resolution_clock::now();
        auto duracion = duration_cast<milliseconds>(t_fin - t_inicio).count();
        cout << "[Resumen] Duracion total de esta operacion: " << duracion << " ms\n";

    } while (opcion_principal != 4);

    auto fin = high_resolution_clock::now();
    auto total = duration_cast<milliseconds>(fin - inicio).count();
    cout << "\nTiempo total de ejecucion del programa: " << total << " ms\n";

    return 0;
}