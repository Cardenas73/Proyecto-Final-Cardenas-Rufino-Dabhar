// procesamiento.cpp
#include "procesamiento.h"
#include "ventas.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <limits>
using namespace std;

// ========================
// VARIABLES GLOBALES
// ========================

map<string, map<string, float>> monto_por_producto_pais;
map<string, map<string, pair<float, int>>> promedio_categoria_pais;
map<string, map<string, int>> medio_envio_pais;
map<string, map<string, int>> medio_envio_categoria;
map<string, float> monto_por_fecha;
map<string, map<string, int>> estado_envio_pais;
map<string, int> cantidad_producto;

// ========================
// CARGA Y PROCESAMIENTO DE DATOS
// ========================

void cargarCSV(const string &filename)
{
    ventas.clear();
    ifstream file(filename);
    string line;
    getline(file, line); // Encabezado

    while (getline(file, line))
    {
        stringstream stream(line);
        Venta v;
        string cantidad, precio, monto;

        getline(stream, v.id_venta, ',');
        getline(stream, v.fecha, ',');
        getline(stream, v.pais, ',');
        getline(stream, v.ciudad, ',');
        getline(stream, v.cliente, ',');
        getline(stream, v.producto, ',');
        getline(stream, v.categoria, ',');
        getline(stream, cantidad, ',');
        getline(stream, precio, ',');
        getline(stream, monto, ',');
        getline(stream, v.medio_envio, ',');
        getline(stream, v.estado_envio, ',');

        v.cantidad = stoi(cantidad);
        v.precio_unitario = stof(precio);
        v.monto_total = stof(monto);
        ventas.push_back(v);
    }
    cout << "Archivo CSV cargado correctamente. Total de ventas: " << ventas.size() << "\n";
}

void procesarDatos()
{
    monto_por_producto_pais.clear();
    promedio_categoria_pais.clear();
    medio_envio_pais.clear();
    medio_envio_categoria.clear();
    monto_por_fecha.clear();
    estado_envio_pais.clear();
    cantidad_producto.clear();

    for (const auto &v : ventas)
    {
        if_count++;
        monto_por_producto_pais[v.pais][v.producto] += v.monto_total;
        promedio_categoria_pais[v.pais][v.categoria].first += v.monto_total;
        promedio_categoria_pais[v.pais][v.categoria].second += 1;
        medio_envio_pais[v.pais][v.medio_envio]++;
        medio_envio_categoria[v.categoria][v.medio_envio]++;
        monto_por_fecha[v.fecha] += v.monto_total;
        estado_envio_pais[v.pais][v.estado_envio]++;
        cantidad_producto[v.producto] += v.cantidad;
    }
    cout << "Procesamiento de datos completado.\n";
}

// ========================
// MODIFICACIÓN DE DATOS
// ========================

void agregarVenta()
{
    Venta v;
    cout << "-- -Agregar nueva venta-- -";
    cout << "ID de venta: ";
    cin >> v.id_venta;
    cout << "Fecha (ej.: 04/03/2024): ";
    cin.ignore();
    getline(cin, v.fecha);
    cout << "País: ";
    getline(cin, v.pais);
    cout << "Ciudad: ";
    getline(cin, v.ciudad);
    cout << "Cliente: ";
    getline(cin, v.cliente);
    cout << "Producto: ";
    getline(cin, v.producto);
    cout << "Categoría: ";
    getline(cin, v.categoria);
    cout << "Cantidad: ";
    cin >> v.cantidad;
    cout << "Precio unitario: ";
    cin >> v.precio_unitario;
    v.monto_total = v.precio_unitario * v.cantidad;
    cin.ignore();
    cout << "Medio de envío: ";
    getline(cin, v.medio_envio);
    cout << "Estado del envío: ";
    getline(cin, v.estado_envio);
    ventas.push_back(v);
    procesarDatos();
    cout << "Venta agregada correctamente.";
}

void eliminarVenta()
{
    cout << "-- -Eliminar venta-- -";
    cout<< "Ingrese el ID de la venta a eliminar: ";
    string id;
    cin.ignore();
    getline(cin, id);
    auto it = find_if(ventas.begin(), ventas.end(), [&](const Venta &v)
                      { return v.id_venta == id; });
    if (it != ventas.end())
    {
        ventas.erase(it);
        procesarDatos();
        cout << "Venta eliminada correctamente.";
    }
    else
    {
        cout << "No se encontró la venta.";
    }
}

void modificarVenta()
{
    cout << "-- -Modificar venta-- -";
    cout<< "Ingrese el ID de la venta a modificar: ";
    string id;
    cin.ignore();
    getline(cin, id);
    for (auto &v : ventas)
    {
        if (v.id_venta == id)
        {
            string input;
            cout << "Cliente actual: " << v.cliente << "Nuevo cliente(Enter para mantener) : "; getline(cin, input);
                                                                                      if (!input.empty()) v.cliente = input;
            cout << "Ciudad actual: " << v.ciudad << "Nuevaciudad(Enter para mantener) : "; getline(cin, input);
                                                                                   if (!input.empty()) v.ciudad = input;
            cout << "Nueva cantidad (-1 para mantener): ";
            int cant;
            cin >> cant;
            if (cant >= 0)
                v.cantidad = cant;
            cout << "Nuevo precio unitario (-1 para mantener): ";
            float p;
            cin >> p;
            if (p >= 0)
                v.precio_unitario = p;
            v.monto_total = v.precio_unitario * v.cantidad;
            cin.ignore();
            cout << "Nuevo medio de envío (Enter para mantener): ";
            getline(cin, input);
            if (!input.empty())
                v.medio_envio = input;
            cout << "Nuevo estado del envío (Enter para mantener): ";
            getline(cin, input);
            if (!input.empty())
                v.estado_envio = input;
            procesarDatos();
            cout << "Venta modificada correctamente.";
                return;
        }
    }
    cout << "No se encontró ninguna venta con ese ID.";
}

// ========================
// PROCESAMIENTO ESTADÍSTICO
// ========================

void top5CiudadesPorPais() {
    cout << "\n--- Top 5 ciudades con mayor monto de ventas por país ---\n";
    map<string, map<string, float>> pais_ciudad_monto;

    for (const auto& v : ventas) {
        if_count++;
        pais_ciudad_monto[v.pais][v.ciudad] += v.monto_total;
    }

    for (const auto& [pais, ciudades] : pais_ciudad_monto) {
        vector<pair<string, float>> lista_ciudades(ciudades.begin(), ciudades.end());
        sort(lista_ciudades.begin(), lista_ciudades.end(), [](const auto& a, const auto& b) {
            return a.second > b.second;
        });

        cout << "\nPaís: " << pais << "\n";
        int top = min(5, (int)lista_ciudades.size());
        for (int i = 0; i < top; ++i) {
            cout << "  " << lista_ciudades[i].first << " - $" << fixed << setprecision(2) << lista_ciudades[i].second << "\n";
        }
    }
}

void mostrarEstadisticas() {
    cout << "\n--- Estadísticas generales ---\n";

    // Monto total vendido por producto por país
    cout << "\n> Monto total vendido por producto (por país):\n";
    for (const auto& [pais, productos] : monto_por_producto_pais) {
        cout << "País: " << pais << "\n";
        for (const auto& [producto, monto] : productos) {
            cout << "  Producto: " << producto << " - $" << fixed << setprecision(2) << monto << "\n";
        }
    }

    // Promedio de ventas por categoría en cada país
    cout << "\n> Promedio de ventas por categoría (por país):\n";
    for (const auto& [pais, categorias] : promedio_categoria_pais) {
        cout << "País: " << pais << "\n";
        for (const auto& [categoria, data] : categorias) {
            float promedio = data.first / data.second;
            cout << "  Categoría: " << categoria << " - Promedio: $" << fixed << setprecision(2) << promedio << "\n";
        }
    }

    // Medio de envío más utilizado por país
    cout << "\n> Medio de envío más utilizado (por país):\n";
    for (const auto& [pais, medios] : medio_envio_pais) {
        string medio_max;
        int max_val = 0;
        for (const auto& [medio, cantidad] : medios) {
            if (cantidad > max_val) {
                max_val = cantidad;
                medio_max = medio;
            }
        }
        cout << "País: " << pais << " - Medio: " << medio_max << " (" << max_val << " veces)\n";
    }

    // Medio de envío más utilizado por categoría
    cout << "\n> Medio de envío más utilizado (por categoría):\n";
    for (const auto& [categoria, medios] : medio_envio_categoria) {
        string medio_max;
        int max_val = 0;
        for (const auto& [medio, cantidad] : medios) {
            if (cantidad > max_val) {
                max_val = cantidad;
                medio_max = medio;
            }
        }
        cout << "Categoría: " << categoria << " - Medio: " << medio_max << " (" << max_val << " veces)\n";
    }

    // Día con mayor monto de ventas
    cout << "\n> Día con mayor monto total de ventas:\n";
    string dia_max;
    float monto_max = 0.0f;
    for (const auto& [fecha, monto] : monto_por_fecha) {
        if (monto > monto_max) {
            monto_max = monto;
            dia_max = fecha;
        }
    }
    cout << "Día: " << dia_max << " - $" << fixed << setprecision(2) << monto_max << "\n";

    // Estado de envío más frecuente por país
    cout << "\n> Estado de envío más frecuente (por país):\n";
    for (const auto& [pais, estados] : estado_envio_pais) {
        string estado_max;
        int max_est = 0;
        for (const auto& [estado, cantidad] : estados) {
            if (cantidad > max_est) {
                max_est = cantidad;
                estado_max = estado;
            }
        }
        cout << "País: " << pais << " - Estado más frecuente: " << estado_max << " (" << max_est << " veces)\n";
    }

    // Producto más y menos vendido (por unidades)
    cout << "\n> Producto más y menos vendido (por cantidad total):\n";
    string prod_max, prod_min;
    int max_cant = -1, min_cant = numeric_limits<int>::max();

    for (const auto& [producto, cantidad] : cantidad_producto) {
        if (cantidad > max_cant) {
            max_cant = cantidad;
            prod_max = producto;
        }
        if (cantidad < min_cant) {
            min_cant = cantidad;
            prod_min = producto;
        }
    }

    cout << "Producto más vendido: " << prod_max << " (" << max_cant << " unidades)\n";
    cout << "Producto menos vendido: " << prod_min << " (" << min_cant << " unidades)\n";
}

// ========================
// CONSULTAS DINÁMICAS
// ========================

void consultarVentasPorCiudad() {
    cout << "\n--- Consultar ventas por ciudad ---\n";
    cout << "Ingrese el nombre de la ciudad: ";
    string ciudad;
    cin.ignore();
    getline(cin, ciudad);
    bool encontrada = false;

    for (const auto& v : ventas) {
        if_count++;
        if (v.ciudad == ciudad) {
            cout << "ID: " << v.id_venta
                 << " | Cliente: " << v.cliente
                 << " | Producto: " << v.producto
                 << " | Cantidad: " << v.cantidad
                 << " | Monto: $" << fixed << setprecision(2) << v.monto_total << "\n";
            encontrada = true;
        }
    }
    if (!encontrada)
        cout << "No se encontraron ventas en esa ciudad.\n";
}

void consultarVentasPorRangoFechaYPais() {
    cout << "\n--- Consultar ventas por rango de fechas y país ---\n";
    string pais, fecha_inicio, fecha_fin;
    cin.ignore();
    cout << "Ingrese el país: ";
    getline(cin, pais);
    cout << "Ingrese la fecha de inicio (ej.: 01/01/2024): ";
    getline(cin, fecha_inicio);
    cout << "Ingrese la fecha de fin (ej.: 31/12/2024): ";
    getline(cin, fecha_fin);

    bool encontrada = false;

    for (const auto& v : ventas) {
        if (v.pais == pais && v.fecha >= fecha_inicio && v.fecha <= fecha_fin) {
            cout << "Fecha: " << v.fecha
                 << " | ID: " << v.id_venta
                 << " | Cliente: " << v.cliente
                 << " | Producto: " << v.producto
                 << " | Monto: $" << fixed << setprecision(2) << v.monto_total << "\n";
            encontrada = true;
        }
    }
    if (!encontrada)
        cout << "No se encontraron ventas para ese país en ese rango de fechas.\n";
}

void compararDosPaises() {
    cout << "\n--- Comparar dos países ---\n";
    string pais1, pais2;
    cin.ignore();
    cout << "Ingrese el primer país: ";
    getline(cin, pais1);
    cout << "Ingrese el segundo país: ";
    getline(cin, pais2);

    float monto1 = 0, monto2 = 0;
    map<string, int> productos1, productos2;
    map<string, int> envios1, envios2;

    for (const auto& v : ventas) {
        if (v.pais == pais1) {
            monto1 += v.monto_total;
            productos1[v.producto] += v.cantidad;
            envios1[v.medio_envio]++;
        } else if (v.pais == pais2) {
            monto2 += v.monto_total;
            productos2[v.producto] += v.cantidad;
            envios2[v.medio_envio]++;
        }
    }

    auto max_producto = [](const map<string, int>& m) {
        return max_element(m.begin(), m.end(),
            [](const auto& a, const auto& b) { return a.second < b.second; });
    };

    auto max_envio = [](const map<string, int>& m) {
        return max_element(m.begin(), m.end(),
            [](const auto& a, const auto& b) { return a.second < b.second; });
    };

    cout << fixed << setprecision(2);
    cout << "\nMonto total de ventas:\n";
    cout << "  " << pais1 << ": $" << monto1 << "\n";
    cout << "  " << pais2 << ": $" << monto2 << "\n";

    auto prod1 = max_producto(productos1);
    auto prod2 = max_producto(productos2);
    cout << "\nProducto más vendido (por unidades):\n";
    cout << "  " << pais1 << ": " << prod1->first << " (" << prod1->second << " unidades)\n";
    cout << "  " << pais2 << ": " << prod2->first << " (" << prod2->second << " unidades)\n";

    auto env1 = max_envio(envios1);
    auto env2 = max_envio(envios2);
    cout << "\nMedio de envío más usado:\n";
    cout << "  " << pais1 << ": " << env1->first << " (" << env1->second << " veces)\n";
    cout << "  " << pais2 << ": " << env2->first << " (" << env2->second << " veces)\n";
}

void compararDosProductosPorPais() {
    cout << "\n--- Comparar dos productos por país ---\n";
    string prod1, prod2;
    cin.ignore();
    cout << "Ingrese el primer producto: ";
    getline(cin, prod1);
    cout << "Ingrese el segundo producto: ";
    getline(cin, prod2);

    map<string, map<string, pair<int, float>>> resumen;

    for (const auto& v : ventas) {
        if (v.producto == prod1 || v.producto == prod2) {
            resumen[v.pais][v.producto].first += v.cantidad;
            resumen[v.pais][v.producto].second += v.monto_total;
        }
    }

    for (const auto& [pais, productos] : resumen) {
        cout << "\nPaís: " << pais << "\n";
        for (const auto& [producto, data] : productos) {
            cout << "  Producto: " << producto << "\n";
            cout << "    Cantidad vendida: " << data.first << "\n";
            cout << "    Monto total: $" << fixed << setprecision(2) << data.second << "\n";
        }
    }
}

void buscarProductosPorDebajoDelUmbral() {
    cout << "\n--- Buscar productos por debajo de umbral promedio ---\n";
    string pais;
    float umbral;
    cin.ignore();
    cout << "Ingrese el país: ";
    getline(cin, pais);
    cout << "Ingrese el umbral promedio por unidad: ";
    cin >> umbral;

    map<string, pair<int, float>> resumen;

    for (const auto& v : ventas) {
        if (v.pais == pais) {
            resumen[v.producto].first += v.cantidad;
            resumen[v.producto].second += v.monto_total;
        }
    }

    bool encontrado = false;
    cout << "\nProductos con promedio menor a $" << fixed << setprecision(2) << umbral << " en " << pais << ":\n";
    for (const auto& [producto, data] : resumen) {
        float promedio = data.second / data.first;
        if (promedio < umbral) {
            cout << "  " << producto << " (Promedio: $" << promedio << ")\n";
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontraron productos por debajo del umbral.\n";
}

void buscarProductosPorEncimaDelUmbral() {
    cout << "\n--- Buscar productos por encima de umbral promedio ---\n";
    string pais;
    float umbral;
    cin.ignore();
    cout << "Ingrese el país: ";
    getline(cin, pais);
    cout << "Ingrese el umbral promedio por unidad: ";
    cin >> umbral;

    map<string, pair<int, float>> resumen;

    for (const auto& v : ventas) {
        if (v.pais == pais) {
            resumen[v.producto].first += v.cantidad;
            resumen[v.producto].second += v.monto_total;
        }
    }

    bool encontrado = false;
    cout << "\nProductos con promedio mayor a $" << fixed << setprecision(2) << umbral << " en " << pais << ":\n";
    for (const auto& [producto, data] : resumen) {
        float promedio = data.second / data.first;
        if (promedio > umbral) {
            cout << "  " << producto << " (Promedio: $" << promedio << ")\n";
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontraron productos por encima del umbral.\n";
}


