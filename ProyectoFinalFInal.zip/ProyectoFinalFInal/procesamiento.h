// procesamiento.h
#ifndef PROCESAMIENTO_H
#define PROCESAMIENTO_H

#include <string>

void cargarCSV(const std::string& filename);
void procesarDatos();
void top5CiudadesPorPais();
void mostrarEstadisticas();
void agregarVenta();
void eliminarVenta();
void modificarVenta();
void consultarVentasPorCiudad();
void consultarVentasPorRangoFechaYPais();
void compararDosPaises();
void compararDosProductosPorPais();
void buscarProductosPorDebajoDelUmbral();
void buscarProductosPorEncimaDelUmbral();

#endif // PROCESAMIENTO_H
