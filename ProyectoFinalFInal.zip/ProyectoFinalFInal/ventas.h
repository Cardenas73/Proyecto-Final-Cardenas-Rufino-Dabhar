#ifndef VENTAS_H
#define VENTAS_H

#include <string>
#include <vector>

using namespace std;

struct Venta {
    string id_venta;
    string fecha;
    string pais;
    string ciudad;
    string cliente;
    string producto;
    string categoria;
    string medio_envio;
    string estado_envio;
    int cantidad;
    float precio_unitario;
    float monto_total;
};

extern vector<Venta> ventas;
extern int if_count;

#endif // VENTAS_H
